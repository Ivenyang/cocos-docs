#include "HelloWorldScene.h"

USING_NS_CC;

Scene* HelloWorld::createScene()
{
    // 'scene' is an autorelease object
	auto scene = Scene::createWithPhysics();

	scene->getPhysicsWorld()->setDebugDrawMask(PhysicsWorld::DEBUGDRAW_ALL);

	Vect gravity = Vect(0.0f, 0.0f);
	scene->getPhysicsWorld()->setGravity(gravity);

    
    // 'layer' is an autorelease object
    auto layer = HelloWorld::create();

	layer->setPhyWorld(scene->getPhysicsWorld());

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Layer::init() )
    {
        return false;
    }

	_spriteSheet = SpriteBatchNode::create("sprites.png", 2);
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("sprites.plist", "sprites.png");
	this->addChild(_spriteSheet);
	this->spawnCar();
	this->schedule(schedule_selector(HelloWorld::secondUpadte), 1.0f);
	this->scheduleUpdate();

    return true;
}

void HelloWorld::spawnCar()
{
	SpriteFrame* frame = SpriteFrameCache::getInstance()->spriteFrameByName("car.png");
	Sprite* car = Sprite::createWithSpriteFrame(frame);
	car->setPosition(Point(100, 100));
	addBoxBodyForSprite(car);
	car->setTag(2);
	car->runAction(MoveTo::create(1.0f, Point(300, 300)));
	car->runAction(RepeatForever::create(Sequence::create(MoveTo::create(1.0,Point(300, 100)),MoveTo::create(1.0,Point(200, 200)),MoveTo::create(1.0,Point(100, 100)),NULL)));
	_spriteSheet->addChild(car);
}

void HelloWorld::spawnCat()
{
	auto winSize = Director::getInstance()->getWinSize();

	auto cat = Sprite::createWithSpriteFrameName("cat.png");

	int minY = cat->getContentSize().height / 2;
	int maxY = winSize.height - (cat->getContentSize().height / 2);
	int rangeY = maxY - minY;
	int actualY = CCRANDOM_0_1() * rangeY;

	int startX = winSize.width + (cat->getContentSize().width / 2);
	int endX = -(cat->getContentSize().width / 2);

	Point startPos = Point(startX, actualY);
	Point endPos = Point(endX, actualY);

	cat->setPosition(startPos);
	addBoxBodyForSprite(cat);
	cat->setTag(1);
	cat->runAction(Sequence::create(MoveTo::create(1.0, endPos), CallFuncN::create(this, callfuncN_selector(HelloWorld::spriteDone)),NULL));

	_spriteSheet->addChild(cat);
	
}

void HelloWorld::addBoxBodyForSprite(Sprite* sprite)
{
	auto body = PhysicsBody::createBox(sprite->getContentSize());
	body->setDynamic(false);
	sprite->setPhysicsBody(body);
}

void HelloWorld::secondUpadte(float dt)
{
	this->spawnCat();
}

void HelloWorld::spriteDone(Node* sender)
{
	Sprite *sprite = (Sprite*)sender;
	_spriteSheet->removeChild(sprite,true);
}

void HelloWorld::onEnter()
{
	Layer::onEnter();

	auto contactListener = EventListenerPhysicsContact::create();
	contactListener->onContactBegin = CC_CALLBACK_2(HelloWorld::onContactBegin, this);

	auto dispatcher = Director::getInstance()->getEventDispatcher();

	dispatcher->addEventListenerWithSceneGraphPriority(contactListener, this);
}

bool HelloWorld::onContactBegin(EventCustom* event, const PhysicsContact& contact)
{
	auto spriteA = (Sprite*)contact.getShapeA()->getBody()->getNode();
	auto spriteB = (Sprite*)contact.getShapeB()->getBody()->getNode();

	if (spriteA->getTag() == 1)
	{
		spriteA->removeFromParentAndCleanup(true);
	}

	if (spriteB->getTag() == 1)
	{
		spriteB->removeFromParentAndCleanup(true);
	}

	return true;
}