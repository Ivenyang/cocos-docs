//
//  Level.cpp
//  SampleGame
//
//  Created by Denger on 14-1-30.
//
//

#include "Level.h"

Level::Level(int levelNum, float spawnRate, std::string bgImageName)
{
    _levelNum = levelNum;
    _spawnRate = spawnRate;
    _bgImageName = bgImageName;
}

Level::~Level()
{
}

Level* Level::create(int levelNum, float spawnRate, std::string bgImageName)
{
    Level * level = new Level(levelNum, spawnRate, bgImageName);
    if (level)
    {
        level->autorelease();
    }
    else
    {
        CC_SAFE_DELETE(level);
    }
	return level;
}