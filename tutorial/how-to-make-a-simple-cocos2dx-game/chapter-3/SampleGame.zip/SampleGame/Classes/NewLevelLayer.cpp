//
//  NewLevelLayer.cpp
//  SampleGame
//
//  Created by Denger on 14-1-30.
//
//

#include "NewLevelLayer.h"
#include "HelloWorldScene.h"
#include "AppDelegate.h"

USING_NS_CC;


bool NewLevelScene::init()
{
	if( Scene::init() )
	{
		this->_layer = NewLevelLayer::create();
        this->_layer->retain();
		this->addChild(_layer);
		
		return true;
	}
	else
	{
		return false;
	}
}

NewLevelScene::~NewLevelScene()
{
    if (_layer)
	{
		_layer->release();
		_layer = NULL;
	}
}

bool NewLevelLayer::init()
{
	if ( LayerColor::initWithColor( Color4B(255,255,255,255) ) )
	{
		auto winSize = Director::getInstance()->getWinSize();
		LabelTTF* label = LabelTTF::create("Get Ready!!","Artial", 32);
		label->retain();
		label->setColor( Color3B(0, 0, 0) );
		label->setPosition( Point(winSize.width/2, winSize.height/2) );
		this->addChild(label);
		
        return true;
	}
	else
	{
		return false;
	}
}

void NewLevelLayer::reset()
{
    this->runAction( Sequence::create(
                                      DelayTime::create(3.0f),
                                      CallFuncN::create(CC_CALLBACK_0(NewLevelLayer::newLevelDone,this)),
                                      NULL));
}

void NewLevelLayer::newLevelDone()
{
    ( (AppDelegate*)Application::getInstance() )->nextLevel();
}

