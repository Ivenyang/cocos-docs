//
//  Level.h
//  SampleGame
//
//  Created by Denger on 14-1-30.
//
//

#ifndef __SampleGame__Level__
#define __SampleGame__Level__

#include "cocos2d.h"

class Level : public cocos2d::Object
{
private:
    int _levelNum;
public:
    Level(int levelNum, float spawnRate, std::string bgImageName);
    ~Level();
    static Level* create(int levelNum, float spawnRate, std::string bgImageName);
    
    CC_SYNTHESIZE_READONLY(std::string, _bgImageName, BgImageName);
    CC_SYNTHESIZE_READONLY(float, _spawnRate, SpawnRate);
};

#endif /* defined(__SampleGame__Level__) */
