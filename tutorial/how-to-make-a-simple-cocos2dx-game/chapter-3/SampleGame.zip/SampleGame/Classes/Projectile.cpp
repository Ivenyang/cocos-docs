//
//  Projectile.cpp
//  SampleGame
//
//  Created by Denger on 14-1-31.
//
//

#include "Projectile.h"
USING_NS_CC;

Projectile::Projectile()
{
}

Projectile::~Projectile()
{
    _monstersHit.clear();
}

Projectile* Projectile::create(const std::string& filename)
{
    Projectile * pRet = new Projectile();
    if (pRet && pRet->initWithFile(filename))
    {
        pRet->autorelease();
    }
    else
    {
        CC_SAFE_DELETE(pRet);
    }
	return pRet;
}

bool Projectile::shouldDamageMonster(Sprite* monster)
{
    if (_monstersHit.contains(monster))
    {
        return false;
    }
    else
    {
        _monstersHit.pushBack(monster);
        return true;
    }
}







