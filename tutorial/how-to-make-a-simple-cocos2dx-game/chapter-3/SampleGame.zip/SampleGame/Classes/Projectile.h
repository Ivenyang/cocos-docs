//
//  Projectile.h
//  SampleGame
//
//  Created by Denger on 14-1-31.
//
//

#ifndef __SampleGame__Projectile__
#define __SampleGame__Projectile__

#include "cocos2d.h"

class Projectile : public cocos2d::Sprite
{
public:
    Projectile();
    virtual ~Projectile();
    static Projectile* create(const std::string& filename);
    
    CC_SYNTHESIZE_READONLY(cocos2d::Vector<cocos2d::Sprite*>, _monstersHit, MonstersHit);
public:
    bool shouldDamageMonster(Sprite* monster);
};

#endif /* defined(__SampleGame__Projectile__) */
