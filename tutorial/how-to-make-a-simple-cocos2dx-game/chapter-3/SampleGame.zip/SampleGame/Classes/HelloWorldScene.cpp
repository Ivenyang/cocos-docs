#include "HelloWorldScene.h"
#include "Monster.h"
#include "SimpleAudioEngine.h"
#include "AppDelegate.h"

USING_NS_CC;

void HelloWorld::onEnter()
{
	LayerColor::onEnter();
	auto listener = EventListenerTouchOneByOne::create();
	listener->setSwallowTouches(true);
    
    listener->onTouchBegan = [=](cocos2d::Touch* touch,cocos2d::Event* event)
    {
        return true;
    };
	listener->onTouchEnded = CC_CALLBACK_2(HelloWorld::onTouchEnded, this);
    
	_eventDispatcher->addEventListenerWithSceneGraphPriority(listener, this);
}

void HelloWorld::update(float t)
{
	Vector<Projectile*> projectilesToDelete;
    
	for (int i=0; i<_projectiles.size(); i++)
	{
        Projectile* projectile = _projectiles.at(i);
		auto projectileRect = Rect(
                                   projectile->getPositionX() - projectile->getContentSize().width / 2,
                                   projectile->getPositionY() - projectile->getContentSize().height / 2,
                                   projectile->getContentSize().width,
                                   projectile->getContentSize().height );
        
        bool monsterHit = false;
        Vector<Sprite*> targetsToDelete;
		for (int j = 0; j < _targets.size(); j++)
		{
			auto target = _targets.at(j);
			auto targetRect = Rect(
                                   target->getPositionX() - target->getContentSize().width / 2,
                                   target->getPositionY() - target->getContentSize().height / 2,
                                   target->getContentSize().width,
                                   target->getContentSize().height);
            
			if (projectileRect.intersectsRect(targetRect))
			{
                if (!projectile->shouldDamageMonster(target)) continue;
                
                //targetsToDelete.pushBack(target);
                monsterHit = true;
                Monster *monster = (Monster *)target;
                --monster->curHp;
                if (monster->curHp <= 0) {
                    _score ++;
                    targetsToDelete.pushBack(target);
                }
                break;
            }
		}
        
		//C++11 的 range-based for循环
		for (Sprite* target : targetsToDelete)
		{
			_targets.eraseObject(target);
			this->removeChild(target);
            
            _projectilesDestroyed++;
            if (_projectilesDestroyed >3) {
                
                ((AppDelegate*)Application::getInstance())->levelComplete();
            }
		}
        
		//projectilesToDelete.pushBack(projectile);
        if (monsterHit)
        {
            projectilesToDelete.pushBack(projectile);
            CocosDenshion::SimpleAudioEngine::getInstance()->playBackgroundMusic("explosion.caf");
        }

		targetsToDelete.clear();
	}
	
	for (const auto& p : projectilesToDelete)
	{
		_projectiles.eraseObject(p);
		this->removeChild(p);
	}
	projectilesToDelete.clear();
    
    // Update score only when it changes for efficiency
    if (_score != _oldScore) {
        _oldScore = _score;
        char temp[8];
        sprintf(temp, "%d", _score);
        _scoreLabel->setString(temp);
    }
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    if ( !LayerColor::initWithColor(Color4B(255,255,255,255)) )
    {
        return false;
    }
    
    Size visibleSize = Director::getInstance()->getVisibleSize();
    
    //创建精灵
    _player = Sprite::create("Player2.png");
	_player->setPosition(Point(_player->getContentSize().width/2 +100, visibleSize.height / 2));
	this->addChild(_player, 1);
    
    // Set up score and score label
    _score = 0;
    _oldScore = -1;
    this->_scoreLabel = LabelTTF::create("", "Marker Felt", 32, Size(100, 50), TextHAlignment::RIGHT);
    //_scoreLabel->setPosition( Point(visibleSize.width - _scoreLabel->getContentSize().width/2, _scoreLabel->getContentSize().height/2) );
    _scoreLabel->setPosition( Point(visibleSize.width - _scoreLabel->getDimensions().width/2, _scoreLabel->getDimensions().height/2) );
    _scoreLabel->setColor(Color3B(0, 0, 0));
    this->addChild(_scoreLabel, 1);
    
    // Start up timers
    this->schedule(schedule_selector(HelloWorld::gameLogic), 1.0f);
    this->scheduleUpdate();
    
    // Start up the background music
    CocosDenshion::SimpleAudioEngine::getInstance()->playBackgroundMusic("background-music-aac.caf");
    
    return true;
}

void HelloWorld::gameLogic(float dt)
{
    static double lastTimeTargetAdded = 0;
    //get now time
    struct timeval tv;
    gettimeofday(&tv,NULL);
    double now = tv.tv_sec * 1000 + tv.tv_usec / 1000;
    
    if( lastTimeTargetAdded == 0 ||
       now - lastTimeTargetAdded >= ((AppDelegate*)Application::getInstance())->curLevel()->getSpawnRate() )
    {
        this->addTarget();
        lastTimeTargetAdded = now;
    }	
}

void HelloWorld::addTarget()
{
	Size visibleSize = Director::getInstance()->getVisibleSize();
    
	//auto target = Sprite::create("Target.png", Rect(0, 0, 27, 40));
    Monster *target = NULL;
    int temp = CCRANDOM_0_1()*100;
    if ( temp % 2 == 0 )
    {
        target = WeakAndFastMonster::monster();
    }
    else
    {
        target = StrongAndSlowMonster::monster();
    }
    
    // Determine where to spawn the target along the Y axis
	int minY = target->getContentSize().height / 2;
	int maxY = visibleSize.height - target->getContentSize().height / 2;
	int rangeY = maxY - minY;
	int actualY = (CCRANDOM_0_1() * rangeY) + minY;
	target->setPosition(Point(visibleSize.width + target->getContentSize().width / 2, actualY));
	this->addChild(target,0);
    
    // Create the target slightly off-screen along the right edge,
    // and along a random position along the Y axis as calculated above
	/* int minDuration = 2.0; 
     int maxDuration = 4.0;*/
    int minDuration = target->minMoveDuration; //2.0;
    int maxDuration = target->maxMoveDuration; //4.0;
	int rangeDuration = maxDuration - minDuration;
	int actualDuration = (CCRANDOM_0_1() * rangeDuration) + minDuration;
    
    
    // Create the actions
	auto actionMove = MoveTo::create(actualDuration, Point(-target->getContentSize().width, actualY));
	auto actionMoveDone = CallFuncN::create(CC_CALLBACK_1(HelloWorld::spriteMoveFinished, this));
    target->runAction(Sequence::create(actionMove, actionMoveDone, NULL));
    
    
    // Add to targets array
    target->setTag(1);
    _targets.pushBack(target);
}

void HelloWorld::onTouchEnded(Touch* touch, Event* event)
{
    if (NULL != _nextProjectile) return;
    
    // Choose touch to work with
	auto touchPoint = touch->getLocation();
    
    // Play a sound!
    CocosDenshion::SimpleAudioEngine::getInstance()->playEffect("pew-pew-lei.caf");
    
    // Set up initial location of projectile
	_nextProjectile = Projectile::create("Projectile2.png");
	_nextProjectile->setPosition(_player->getPosition());
    
    // Rotate player to face shooting direction
    Point shootVector = touchPoint - _nextProjectile->getPosition();
    float shootAngle = shootVector.getAngle();
    float cocosAngle = CC_RADIANS_TO_DEGREES(-1 * shootAngle);
    
    float curAngle = _player->getRotation();
    float rotateDiff = cocosAngle - curAngle;
    if (rotateDiff > 180)
		rotateDiff -= 360;
	if (rotateDiff < -180)
		rotateDiff += 360;
    float rotateSpeed = 0.5 / 180; // Would take 0.5 seconds to rotate half a circle
    float rotateDuration = fabs(rotateDiff * rotateSpeed);
    
    // Move player slightly backwards
    _player->runAction(Sequence::create(
                                        RotateTo::create(rotateDuration, cocosAngle),
                                        CallFuncN::create(CC_CALLBACK_0(HelloWorld::finishShoot, this)),
                                        NULL));
    
    // Move projectile offscreen
    float delta = 1.0;
    Point normalizedShootVector = shootVector.normalize();
    Point overshotVector = normalizedShootVector * 740;
    Point offscreenPoint = _nextProjectile->getPosition() + overshotVector;
    
    // Move projectile to actual endpoint
	_nextProjectile->runAction(
                        Sequence::create(MoveTo::create(delta, offscreenPoint),
        CallFuncN::create(CC_CALLBACK_1(HelloWorld::spriteMoveFinished, this)),
                                                NULL));

    // set tag
    _nextProjectile->setTag(2);
}
                       
void HelloWorld::finishShoot()
{
    // Ok to add now - we've finished rotation!
    this->addChild(_nextProjectile, 1);
    // Add to projectiles vector
    _projectiles.pushBack(_nextProjectile);
    
    _nextProjectile = NULL;
}

void HelloWorld::spriteMoveFinished(Object* pSender)
{
	Sprite *sprite = (Sprite *)pSender;
    
    if (sprite->getTag() == 1)
    {
        // target
		_targets.eraseObject(sprite);
        
        /*auto gameOverScene = GameOverScene::create();
        gameOverScene->getLayer()->getLabel()->setString("You Lose :[");
        Director::getInstance()->replaceScene(gameOverScene);*/
        ( (AppDelegate*)Application::getInstance() )->loadGameOverScene();
	}
    else if(sprite->getTag() == 2)
    {
        // projectile
		_projectiles.eraseObject((Projectile*)sprite);
	}
    
    this->removeChild(sprite);
}

void HelloWorld::reset()
{
    // Clear out any objects
    for (Sprite *target : _targets)
    {
        this->removeChild(target);
    }
    if(!_targets.empty())
        _targets.clear();
    for (Projectile *projectile : _projectiles)
    {
        this->removeChild(projectile);
    }
    if(!_projectiles.empty())
        _projectiles.clear();
    
    // Remove old bg if it exists
    if (_curBg != NULL)
    {
        this->removeChild(_curBg);
        this->_curBg = NULL;
    }
    
    // Add new bg
    auto *bg = Sprite::create( ((AppDelegate*)Application::getInstance())->curLevel()->getBgImageName() );
    bg->setPosition(Point(480, 320));
    this->addChild(bg);
    
    // Store reference to current background so we can remove it on next reset
    this->_curBg = bg;
    
    // Reset stats
    _projectilesDestroyed = 0;
    _nextProjectile = NULL;
    
    //不unscheduleUpdate的话在debug模式下调试时会有错。
    this->unscheduleUpdate();
    // Start up timers again
    this->schedule(schedule_selector(HelloWorld::gameLogic), 1.0f);
    this->scheduleUpdate();
    
    // Don't forget to reset score!  (via @Mark W)
    _score = 0;
    _oldScore = -1;
}

void HelloWorld::menuCloseCallback(Object* pSender)
{
    Director::getInstance()->end();

#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    exit(0);
#endif
}


bool HelloWorldScene::init()
{
    if( Scene::init() )
	{
		this->_layer = HelloWorld::create();
        this->_layer->retain();
		this->addChild(_layer);
		
		return true;
	}
	else
	{
		return false;
	}
}

HelloWorldScene::~HelloWorldScene()
{
    
    if (_layer)
	{
		_layer->release();
		_layer = NULL;
	}
}
