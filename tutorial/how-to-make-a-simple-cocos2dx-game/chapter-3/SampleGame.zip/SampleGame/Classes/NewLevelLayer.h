//
//  NewLevelLayer.h
//  SampleGame
//
//  Created by Denger on 14-1-30.
//
//

#ifndef __SampleGame__NewLevelLayer__
#define __SampleGame__NewLevelLayer__

#include "cocos2d.h"

class NewLevelLayer : public cocos2d::LayerColor
{
public:
    NewLevelLayer() {};
    virtual ~NewLevelLayer() {};
    bool init();
    CREATE_FUNC(NewLevelLayer);
    
    void reset();
    void newLevelDone();
};


class NewLevelScene : public cocos2d::Scene
{
public:
    NewLevelScene():_layer(NULL) {};
    virtual ~NewLevelScene();
    bool init();
    CREATE_FUNC(NewLevelScene);
    
    CC_SYNTHESIZE_READONLY(NewLevelLayer*, _layer, Layer);
};

#endif /* defined(__SampleGame__NewLevelLayer__) */
