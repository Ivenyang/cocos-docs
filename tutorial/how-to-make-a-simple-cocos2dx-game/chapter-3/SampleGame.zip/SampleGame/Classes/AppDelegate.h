#ifndef  _APP_DELEGATE_H_
#define  _APP_DELEGATE_H_

#include "cocos2d.h"
#include "Level.h"
#include "HelloWorldScene.h"
#include "NewLevelLayer.h"

/**
@brief    The cocos2d Application.

The reason for implement as private inheritance is to hide some interface call by Director.
*/
class  AppDelegate : private cocos2d::Application
{
public:
    AppDelegate();
    virtual ~AppDelegate();

    /**
    @brief    Implement Director and Scene init code here.
    @return true    Initialize success, app continue.
    @return false   Initialize failed, app terminate.
    */
    virtual bool applicationDidFinishLaunching();

    /**
    @brief  The function be called when the application enter background
    @param  the pointer of the application
    */
    virtual void applicationDidEnterBackground();

    /**
    @brief  The function be called when the application enter foreground
    @param  the pointer of the application
    */
    virtual void applicationWillEnterForeground();
    
public:
    Level* curLevel();
    void nextLevel();
    void levelComplete();
    void restartGame();
    void loadGameOverScene();
    void loadWinScene();
    void loadNewLevelScene();
    
    CC_SYNTHESIZE_READONLY(int, _curLevelIndex, CurLevelIndex);
    CC_SYNTHESIZE_READONLY(cocos2d::Vector<Level *>, _levels, Levels);
    CC_SYNTHESIZE_READONLY(HelloWorldScene *, _mainScene, MainScene);
    CC_SYNTHESIZE_READONLY(GameOverScene *, _gameOverScene, GameOverScene);
    CC_SYNTHESIZE_READONLY(NewLevelScene *, _newLevelScene, NewLevelScene);
};

#endif // _APP_DELEGATE_H_

