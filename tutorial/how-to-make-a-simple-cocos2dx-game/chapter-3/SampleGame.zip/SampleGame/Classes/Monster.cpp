#include "Monster.h"

WeakAndFastMonster* WeakAndFastMonster::monster(void)
{
    WeakAndFastMonster * monster = new WeakAndFastMonster();
    if (monster && monster->initWithFile("Target.png"))
    {
        monster->curHp =1;
        monster->minMoveDuration =3;
        monster->maxMoveDuration =5;
        
        monster->autorelease();
    }
    else
    {
        CC_SAFE_DELETE(monster);
    }
	return monster;
}

StrongAndSlowMonster* StrongAndSlowMonster::monster(void)
{
    StrongAndSlowMonster * monster = new StrongAndSlowMonster();
    if (monster && monster->initWithFile("Target2.png"))
    {
        monster->curHp = 3;
        monster->minMoveDuration = 6;
        monster->maxMoveDuration = 12;
        
        monster->autorelease();
    }
    else
    {
        CC_SAFE_DELETE(monster);
        
    }
	return monster;
}