#ifndef __HELLOWORLD_SCENE_H__
#define __HELLOWORLD_SCENE_H__

#include "cocos2d.h"
#include "GameOverScene.h"
#include "Projectile.h"

class HelloWorld : public cocos2d::LayerColor
{
public:
    // Here's a difference. Method 'init' in cocos2d-x returns bool, instead of returning 'id' in cocos2d-iphone
    virtual bool init();
    // a selector callback
    void menuCloseCallback(Object* pSender);
    // implement the "static create()" method manually
    CREATE_FUNC(HelloWorld);
    virtual void onEnter();
    virtual void update(float t);
public:
    void addTarget();
    void finishShoot();
    void spriteMoveFinished(Object* pSender);
    void gameLogic(float dt);
    void onTouchEnded(cocos2d::Touch* touch, cocos2d::Event* event);
    void reset();
    
    CC_SYNTHESIZE_READONLY(cocos2d::LabelTTF *, _scoreLabel, Label);
private:
	int _projectilesDestroyed;
    int _score;
    int _oldScore;
    
    cocos2d::Vector<cocos2d::Sprite*> _targets;
    cocos2d::Vector<Projectile*> _projectiles;
    
    cocos2d::Sprite* _curBg;
    cocos2d::Sprite* _player;
    Projectile *_nextProjectile;
};


class HelloWorldScene : public cocos2d::Scene
{
public:
    HelloWorldScene():_layer(NULL) {};
    ~HelloWorldScene();
    bool init();
    CREATE_FUNC(HelloWorldScene);
    CC_SYNTHESIZE_READONLY(HelloWorld*, _layer, Layer);
};

#endif // __HELLOWORLD_SCENE_H__


