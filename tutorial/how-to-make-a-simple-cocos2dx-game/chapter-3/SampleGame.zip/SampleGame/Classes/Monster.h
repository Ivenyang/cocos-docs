#ifndef __SampleGame3__Monster__
#define __SampleGame3__Monster__

#include "cocos2d.h"

class Monster : public cocos2d::Sprite
{
public:
	int curHp;
	int minMoveDuration;
	int maxMoveDuration;
};

class WeakAndFastMonster : public Monster
{
public:
    
    static WeakAndFastMonster* monster(void);
    
};

class StrongAndSlowMonster : public Monster
{
public:

    static StrongAndSlowMonster* monster(void);
    
};

#endif /* defined(__SampleGame3__Monster__) */
