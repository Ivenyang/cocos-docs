#include "PlayLayer.h"

enum {ktagSpriteSheet = 1,};

bool PlayLayer::init()
{
	if (!Layer::init())
	{
		return false;
	}
	
	auto background = Sprite::create("Terrain.png");
	background->setPosition(ccp(160,240));
	this->addChild(background);

	auto texture = TextureCache::getInstance()->addImage("dragon.png");

	auto sheet = SpriteBatchNode::create("dragon.png",10);

	this->addChild(sheet, 0, ktagSpriteSheet);

	Size s = Director::getInstance()->getWinSize();

	Vector<SpriteFrame*> animFrames;
	for (int i = 0; i < 8; i++)
	{
		animFrames.clear();

		for (int j = 0; j < 10; j++)
		{
			auto frame = SpriteFrame::createWithTexture(texture, Rect(j * 75, i * 70, 75, 70), false, Director::getInstance()->getVisibleOrigin(), Size(75, 70));
			animFrames.pushBack(frame);
		}
		auto animation = Animation::createWithSpriteFrames(animFrames, 0.1f);

		auto animate = Animate::create(animation);
		auto seq = Sequence::create(animate, NULL);

		this->flyAction = RepeatForever::create(seq);
		flyActionArray.pushBack(this->flyAction);
	}
	
	auto frame1 = SpriteFrame::createWithTexture(texture, Rect(0, 0, 75, 70), false, Director::getInstance()->getVisibleOrigin(), Size(75, 70));

	this->dragon = Sprite::createWithSpriteFrame(frame1);
	dragon->setPosition(ccp(s.width/2-80,s.height/2));

	sheet->addChild(dragon);

	this->flyAction = flyActionArray.at(0);
	dragon->runAction(flyAction);

	return true;
}