#pragma once
#include "cocos2d.h"
#include "Adventurer.h"
#include "SceneManager.h"

USING_NS_CC;

class PlayLayer: public Layer
{
public:
	Vector<Action*> flyActionArray;
	Texture2D* texture;
	SpriteBatchNode* spriteSheet;
	Vector<Adventurer*> charArray;
	Sprite* dragon;
	Action* flyAction;
	Action* moveAction;
	bool moving;

	CREATE_FUNC(PlayLayer);
	void gameLogic(float dt);
	void addAdventurer();
	void spriteMoveFinished(Node* sender, void* adv);
	bool virtual init();
};