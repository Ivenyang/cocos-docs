#pragma once
#include "cocos2d.h"
#include "PlayLayer.h"

USING_NS_CC;

class SceneManager: public Object 
{
public:
	static void goPlay();
	static void go(Layer* layer);
	static Scene* wrap(Layer* layer);
};