//
//  CreditLayer.h
//  MenuTutorial
//
//  Created by Denger on 14-2-12.
//
//

#ifndef __MenuTutorial__CreditLayer__
#define __MenuTutorial__CreditLayer__

#include "cocos2d.h"
#include "SceneManager.h"

class CreditLayer : public cocos2d::Layer
{
public:
    CreditLayer();
    ~CreditLayer();
    bool init();
    void back(Object* pSender);
    
    CREATE_FUNC(CreditLayer);
};


#endif /* defined(__MenuTutorial__CreditLayer__) */
