#include "HelloWorldScene.h"

USING_NS_CC;

enum {
	kTagTileMap = 1,
	kTagBatchNode = 1,
	kTagAnimation1 = 1,
};

Scene* HelloWorld::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::createWithPhysics();

	//scene->getPhysicsWorld()->setDebugDrawMask(PhysicsWorld::DEBUGDRAW_ALL);

    // 'layer' is an autorelease object
    auto layer = HelloWorld::create();

	layer->setPhyWorld(scene->getPhysicsWorld());

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Layer::init() )
    {
        return false;
    }

	auto visibleSize = Director::getInstance()->getVisibleSize();
	auto origin = Director::getInstance()->getVisibleOrigin();
    
	this->addScrollingBackgroundWithTileMap();
	this->drawCollisionTiles();

	auto sprite = Sprite::create("Icon-Small.png");
	sprite->setPosition(100.0f, 600.0f);
	playerBody = PhysicsBody::createCircle(1.0f);
	playerBody->getShape(0)->setRestitution(1.0f);
	playerBody->getShape(0)->setFriction(0.0f);
	playerBody->getShape(0)->setDensity(1.0f);
	Vect impulse = Vect(1000.0f, 0);
	playerBody->applyImpulse(impulse);
	sprite->setPhysicsBody(playerBody);
	this->addChild(sprite);

	auto edgeSp = Sprite::create();
	Size size = Size(tileMapNode->getMapSize().width * 16, visibleSize.height);
	auto boundBody = PhysicsBody::createEdgeBox(size, PHYSICSBODY_MATERIAL_DEFAULT, 3);
	edgeSp->setPosition(Point(tileMapNode->getMapSize().width*16/2, visibleSize.height/2));
	edgeSp->setPhysicsBody(boundBody); 
	this->addChild(edgeSp);
	edgeSp->setTag(0);

	
	
	this->scheduleUpdate();
    
    return true;
}

void HelloWorld::update(float dt)
{
	Point pos = playerBody->getPosition();
	this->setPosition(-1 * pos.x+100, this->getPositionY());
}

void HelloWorld::addScrollingBackgroundWithTileMap()
{
	tileMapNode = TMXTiledMap::create("scroller.tmx");
	tileMapNode->setAnchorPoint(Point(0, 0));
	this->addChild(tileMapNode);
}

void HelloWorld::drawCollisionTiles()
{
	TMXObjectGroup *objects = tileMapNode->objectGroupNamed("Collision");

	float x, y, w, h;
	ValueVector objectsPoint = objects->getObjects();
	Value objPointMap;
	for each(objPointMap in objectsPoint)
	{
		ValueMap objPoint = objPointMap.asValueMap();
		x = objPoint.at("x").asFloat();
		y = objPoint.at("y").asFloat();
		w = objPoint.at("width").asFloat();
		h = objPoint.at("height").asFloat();

		Point _point = Point(x + w / 2.0f, y + h / 2.0f);
		Size _size = Size(w, h);

		this->makeBox2dObjAt(_point,_size, false, 0, 0.0f, 0.0f, 0, -1);
	}
}

void HelloWorld::makeBox2dObjAt(Point p, Size size, bool d, float r, float f, float dens, float rest, int boxId)
{
	auto sprite = Sprite::create();
	auto body = PhysicsBody::createBox(size, PHYSICSBODY_MATERIAL_DEFAULT);
	body->setTag(boxId);
	body->getShape(0)->setRestitution(rest);
	body->getShape(0)->setFriction(f);
	body->getShape(0)->setDensity(dens);
	body->setDynamic(d);
	sprite->setPhysicsBody(body);
	sprite->setPosition(p);
	this->addChild(sprite);
}