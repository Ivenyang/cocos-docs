#include "HelloWorldScene.h"


HelloWorld::HelloWorld()
{
    _moving =false;
}

HelloWorld::~HelloWorld()
{
    if (_walkAction)
    {
        _walkAction->release();
        _walkAction = NULL;
    }
}

Scene* HelloWorld::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = HelloWorld::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
// Replace the init method with the following
bool HelloWorld::init()
{
    if ( !Layer::init() )
    {
        return false;
    }
    // Add the stuff from below!
    SpriteFrameCache::getInstance()->addSpriteFramesWithFile("AnimBear.plist");
    auto *spriteSheet = SpriteBatchNode::create("AnimBear.png");
    this->addChild(spriteSheet);
    
    Vector<SpriteFrame*> animFrames(15);
    
    char str[50] = {0};
    for(int i = 1; i < 9; i++)
    {
        sprintf(str, "bear%d.png", i);
        auto frame = SpriteFrameCache::getInstance()->getSpriteFrameByName( str );
        animFrames.pushBack(frame);
    }
    
    auto animation = Animation::createWithSpriteFrames(animFrames, 0.1f);
    
    auto winSize = Director::getInstance()->getWinSize();
    _bear = Sprite::createWithSpriteFrameName("bear1.png");
    _bear->cocos2d::Node::setPosition(Point(winSize.width/2, winSize.height/2));
    _walkAction =  RepeatForever::create( Animate::create(animation) ) ;
    _walkAction->retain();
    //_bear->runAction(_walkAction);
    
    spriteSheet->addChild(_bear);
    
    return true;
}

// Comment out the runAction method in the init method: //_bear->runAction(_walkAction);
// override onEnter() method
void HelloWorld::onEnter()
{
    Layer::onEnter();
    
    auto listener = EventListenerTouchOneByOne::create();
    listener->setSwallowTouches(true);
    listener->onTouchBegan = CC_CALLBACK_2(HelloWorld::onTouchBegan, this);
    listener->onTouchMoved = CC_CALLBACK_2(HelloWorld::onTouchMoved, this);
    listener->onTouchEnded = CC_CALLBACK_2(HelloWorld::onTouchEnded, this);

    _eventDispatcher->addEventListenerWithSceneGraphPriority(listener, this);
}

 // Add these new methods
bool HelloWorld::onTouchBegan(Touch* touch, Event* event)
{
    return true;
}

void HelloWorld::onTouchMoved(Touch* touch, Event* event)
{
}

void HelloWorld::onTouchEnded(Touch* touch, Event* event)
{
    auto touchPoint = touch->getLocation();
    touchPoint = this->convertToNodeSpace(touchPoint);
    
    float bearVelocity = 480.0/3.0;
    Point moveDifference = touchPoint - _bear->getPosition();
    float distanceToMove = moveDifference.getLength();
    float moveDuration = distanceToMove / bearVelocity;
    
    if (moveDifference.x < 0)
    {
        _bear->setFlippedX(false);
    }
    else
    {
        _bear->setFlippedX(true);
    }
    
    _bear->stopAction(_moveAction);
    if (!_moving)
    {
        _bear->runAction(_walkAction);
    }
    _moveAction = Sequence::create(
                            MoveTo::create(moveDuration, touchPoint),
                            CallFunc::create(CC_CALLBACK_0(HelloWorld::bearMoveEnded, this)),
                            NULL);
    
    _bear->runAction(_moveAction);
    _moving = true;
}

void HelloWorld::bearMoveEnded()
{
    _bear->stopAction(_walkAction);
    _moving = false;
}
