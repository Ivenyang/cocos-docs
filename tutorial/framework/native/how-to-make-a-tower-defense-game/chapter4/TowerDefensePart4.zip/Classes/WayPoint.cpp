#include "WayPoint.h"

USING_NS_CC;

bool WayPoint::init()
{
	if (!Node::init())
	{
		return false;
	}

	return true;
}

