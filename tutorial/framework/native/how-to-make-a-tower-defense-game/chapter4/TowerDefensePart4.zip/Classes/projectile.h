#pragma once
#include "cocos2d.h"

USING_NS_CC;

class Projectile: public Sprite 
{
public:
	static Projectile* projectile();
};
