#pragma once

typedef enum {
	kGameObjectNone,
	kGameObjectPlayer,
	kGameObjectPlatform
} GameObjectType;