#ifndef  _CONSTANTS_H_
#define  _CONSTANTS_H_

//debug with resolution 480*320 
#define kTileSize 42.0f//box中每个元素的大小
#define kMoveTileTime 0.3f
#define kBoxWidth 7
#define kBoxHeight 7
#define kStartX 100
#define kStartY 20
#define kKindCount 4


#endif