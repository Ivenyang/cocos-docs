//
//  BaseLayer.h
//  MenuTutorial
//
//  Created by Denger on 14-2-13.
//
//

#ifndef __MenuTutorial__BaseLayer__
#define __MenuTutorial__BaseLayer__

#include "cocos2d.h"

class BaseLayer : public cocos2d::Layer
{
public:
    BaseLayer();
    ~BaseLayer();
    bool init();
    
    CREATE_FUNC(BaseLayer);
};

#endif /* defined(__MenuTutorial__BaseLayer__) */
