#include "SceneManager.h"

void SceneManager::goPlay()
{
	auto layer = PlayLayer::create();
	SceneManager::go(layer);
}

void SceneManager::go(Layer* layer)
{
	auto director = Director::getInstance();
	auto newScene = SceneManager::wrap(layer);

	if (director->getRunningScene())
	{
		director->replaceScene(newScene);
	}
	else
	{
		director->runWithScene(newScene);
	}
}

Scene* SceneManager::wrap(Layer* layer)
{
	auto newScene = Scene::create();
	newScene->addChild(layer);
	return newScene;
}