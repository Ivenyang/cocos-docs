#include "Adventurer.h"

bool Adventurer::init()
{
	if (!Node::init())
	{
		return false;
	}

	return true;
}