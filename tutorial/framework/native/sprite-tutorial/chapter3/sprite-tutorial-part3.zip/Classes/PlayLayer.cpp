#include "PlayLayer.h"

enum {ktagSpriteSheet = 1,};

bool PlayLayer::init()
{
	if (!Layer::init())
	{
		return false;
	}
	
	auto background = Sprite::create("Terrain.png");
	background->setPosition(ccp(160,240));
	this->addChild(background);

	texture = TextureCache::getInstance()->addImage("adventurer.png");
	spriteSheet = SpriteBatchNode::createWithTexture(texture,100);
	this->addChild(spriteSheet,0,ktagSpriteSheet);

	this->schedule(schedule_selector(PlayLayer::gameLogic), 1.0f);

	return true;
}

void PlayLayer::addAdventurer()
{
	Vector<SpriteFrame*>animFrames;

	animFrames.clear();

	for (int i = 0; i < 9; i++) 
	{
		auto *frame = SpriteFrame::createWithTexture(this->texture, Rect(i * 16, 0, 16, 29));
		animFrames.pushBack(frame);
	}

	auto adventurer = Adventurer::create();
	if (adventurer != NULL) 
	{
		auto *frame1 = SpriteFrame::createWithTexture(this->texture, Rect(0, 0, 19, 29));
		adventurer->charSprite = Sprite::createWithSpriteFrame(frame1);

		Size s = Director::getInstance()->getWinSize();

		int minY = adventurer->charSprite->getContentSize().width/2;
		int maxY = s.height - adventurer->charSprite->getContentSize().height / 2;
		int rangeY = maxY - minY;
		int actualY = (CCRANDOM_0_1() * rangeY) + minY;

		int minX = -300;
		int maxX = 0;
		int rangeX = maxX - minX;
		int actualX = (CCRANDOM_0_1() * rangeX) + minX;

		adventurer->charSprite->setPosition(ccp(actualX, actualY));

		auto *animation = Animation::createWithSpriteFrames(animFrames,0.2);
		auto *animate = Animate::create(animation);
		auto *seq = Sequence::create(animate,NULL);
		adventurer->walkAction = RepeatForever::create(seq);

		auto actionMove = MoveTo::create(10.0f,ccp(s.width + 200, actualY));
		auto actionMoveDone = CallFuncN::create(CC_CALLBACK_1(PlayLayer::spriteMoveFinished,this,(void*)adventurer));
		adventurer->moveAction = Sequence::create(actionMove,actionMoveDone,NULL);

		adventurer->charSprite->runAction(adventurer->walkAction);
		adventurer->charSprite->runAction(adventurer->moveAction);

		this->addChild(adventurer->charSprite);
		charArray.pushBack(adventurer);
	}
}

void PlayLayer::spriteMoveFinished(Node* sender, void* adv)
{
	auto adventurer = (Adventurer*)adv;

	Size s = Director::getInstance()->getWinSize();

	int minY = adventurer->charSprite->getContentSize().height / 2;
	int maxY = s.height - adventurer->charSprite->getContentSize().height / 2;
	int rangeY = maxY - minY;
	int actualY = (CCRANDOM_0_1() * rangeY) + minY;

	int minX = -300;
	int maxX = 0;
	int rangeX = maxX - minX;
	int actualX = (CCRANDOM_0_1() * rangeX) + minX;

	adventurer->charSprite->setPosition(ccp(actualX, actualY));

	adventurer->stopAction(adventurer->moveAction);
	adventurer->charSprite->runAction(adventurer->moveAction);

}

void PlayLayer::gameLogic(float dt)
{
	this->addAdventurer();
}