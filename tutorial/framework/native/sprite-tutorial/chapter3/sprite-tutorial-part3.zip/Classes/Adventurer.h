#include "cocos2d.h"

USING_NS_CC;

class Adventurer: public Node 
{
public:
	Sprite* charSprite;
	Action* walkAction;
	Action* moveAction;
	bool moving;

	bool virtual init();
	CREATE_FUNC(Adventurer);
};