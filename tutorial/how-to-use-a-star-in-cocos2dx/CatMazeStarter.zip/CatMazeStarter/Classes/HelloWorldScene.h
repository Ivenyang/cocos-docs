#ifndef __HELLOWORLD_SCENE_H__
#define __HELLOWORLD_SCENE_H__

#include "cocos2d.h"
USING_NS_CC;

class CatSprite;
class HelloWorld : public cocos2d::Layer
{
public:
    HelloWorld();
    ~HelloWorld();
    static cocos2d::Scene* createScene();
    virtual bool init();      
    CREATE_FUNC(HelloWorld);
    bool isWallAtTileCoord(const cocos2d::Point &tileCoord);
    bool isBoneAtTilecoord(const cocos2d::Point &tileCoord);
    bool isDogAtTilecoord(const cocos2d::Point &tileCoord);
    bool isExitAtTilecoord(const cocos2d::Point &tileCoord);
    cocos2d::Point tileCoordForPosition(const cocos2d::Point &position);
    cocos2d::Point positionForTileCoord(const cocos2d::Point &tileCoord);
    void removeObjectAtTileCoord(const cocos2d::Point &tileCoord);
    void winGame();
    void loseGame();
    void showNumBones(int numBones);
	bool isValidTileCoord(const cocos2d::Point &tileCoord);
	PointArray *walkableAdjacentTilesCoordForTileCoord(const Point &tileCoord);
private:
    bool isPropAtTileCoordForLayer(const char *prop, const cocos2d::Point &tileCoord, cocos2d::TMXLayer *layer);
    void setViewpointCenter(const cocos2d::Point &position);
    void showRestartMenu();
    void endScene();
    virtual void update(float delta) override;  
private:
    cocos2d::TMXTiledMap *_tileMap;
    cocos2d::TMXLayer *_bgLayer;
    cocos2d::TMXLayer *_objectLayer;
    cocos2d::SpriteBatchNode *_batchNode;
    CatSprite *_cat;
    bool _gameOver;
    bool _won;
    cocos2d::LabelBMFont *_bonesCount;
};

#endif // __HELLOWORLD_SCENE_H__
