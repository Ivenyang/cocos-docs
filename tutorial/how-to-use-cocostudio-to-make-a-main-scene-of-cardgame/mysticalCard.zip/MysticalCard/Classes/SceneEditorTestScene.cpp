#include "SceneEditorTestScene.h"
#include "CocoStudio/Json/DictionaryHelper.h"
#include "CocoStudio/Reader/SceneReader.h"
#include "CocoStudio/GUI/BaseClasses/UIWidget.h"
#include "HelloWorldScene.h"
using namespace cocos2d;
using namespace cocos2d::extension;


SceneEditorTestLayer::~SceneEditorTestLayer()
{
}

SceneEditorTestLayer::SceneEditorTestLayer()
{
	m_pCurNode = NULL;
}

CCScene* SceneEditorTestLayer::scene()
{
	CCScene * scene = NULL;
	do 
	{
		// 'scene' is an autorelease object
		scene = CCScene::create();
		CC_BREAK_IF(! scene);

		// 'layer' is an autorelease object
		SceneEditorTestLayer *layer = SceneEditorTestLayer::create();
		CC_BREAK_IF(! layer);

		// add layer as a child to scene
		scene->addChild(layer);
	} while (0);

	// return the scene
	return scene;
}

// on "init" you need to initialize your instance
bool SceneEditorTestLayer::init()
{
	bool bRet = false;
	do 
	{
        CC_BREAK_IF(! CCLayerColor::initWithColor( ccc4(0,0,0,255) ) );
        
//        CCSize winSize = CCDirector::sharedDirector()->getWinSize();
//        CCPoint pointCenter = ccp(winSize.width /2, winSize.height / 2);
        
        CCNode *root = createGameScene();
        CC_BREAK_IF(!root);
        root->setPosition(ccp(0, (540 - 480) / 2));
        this->addChild(root, 0, 1);

		bRet = true;
	} while (0);

	return bRet;
}

cocos2d::CCNode* SceneEditorTestLayer::createGameScene()
{
	CCNode *pNode = SceneReader::sharedSceneReader()->createNodeWithSceneFile("McScene.json");
	if (pNode == NULL)
	{
		return NULL;
	}
	m_pCurNode = pNode;
    
    CCComRender *pLoadRender = (CCComRender*)(m_pCurNode->getChildByTag(1)->getChildByTag(1)->getComponent("CCArmature"));
    CCArmature* armLoad = (CCArmature*)(pLoadRender->getNode());
    armLoad->getAnimation()->playByIndex(0, -1, -1, 1);

	//�ӳ����л�ȡui��ť�ؼ�  
	CCComRender *render = (CCComRender*)(m_pCurNode->getChildByTag(1)->getComponent("GUIComponent"));
	cocos2d::gui::TouchGroup* touchGroup = (cocos2d::gui::TouchGroup*)(render->getNode());

	cocos2d::gui::Widget* widget = (cocos2d::gui::Widget*)(touchGroup->getWidgetByName("Panel")->getChildByTag(2));
	cocos2d::gui::UIButton* button = (cocos2d::gui::UIButton*)(widget->getChildByName("btnMenu"));

	//Ϊ��ť���Ӵ����¼�  
	button->addTouchEventListener(this, cocos2d::gui::SEL_TouchEvent(&SceneEditorTestLayer::toExtensionsMainLayer));


    return pNode;
}

void SceneEditorTestLayer::toExtensionsMainLayer(cocos2d::CCObject *sender, cocos2d::gui::TouchEventType type)
{
	CCScene *pScene = HelloWorld::scene();
	switch (type)
	{
	case gui::TOUCH_EVENT_BEGAN:

		break;
	case gui::TOUCH_EVENT_MOVED:
		// TODO
		break;
	case gui::TOUCH_EVENT_ENDED:
		
		CCDirector::sharedDirector()->replaceScene(CCTransitionFadeDown::create(2.0f, pScene));
		// TODO
		break;
	case gui::TOUCH_EVENT_CANCELED:
		// TODO
		break;
	default:
		// TODO
		break;
	}
}


void runSceneEditorTestLayer()
{
}

